# Nigeria Open World — Prototype 0.1

A first browser-based 3D prototype for a fictional Nigerian city district. It includes a walkable character, roads, simple buildings, trees, a market cluster, and fictional yellow minibuses.

## Run it
The easiest way is to publish the repository with GitHub Pages:
1. Upload `index.html`, `src/main.js`, and this README to your repository.
2. In GitHub, open **Settings → Pages**.
3. Under the build/deployment source, choose **Deploy from a branch**.
4. Select the `main` branch and `/ (root)`, then Save.
5. Wait for the Pages URL and open it in a browser with WebGL enabled.

For local testing, use a small local web server rather than opening `index.html` directly, because browser module imports may be blocked for local files.

## Controls
- **WASD / arrow keys**: move
- **Shift**: run
- **Click the game**: capture the mouse
- **Mouse**: rotate the camera while captured

## Important
This is a prototype, not a finished GTA-scale game. The city is a fictional Lagos-inspired district, not an accurate map of Lagos or all of Nigeria. The next stages are touch controls for mobile, collision, vehicles the player can enter, missions, and expanding the map with data for Nigerian states and capitals.
